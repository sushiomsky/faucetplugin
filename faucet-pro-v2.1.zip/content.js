// ── Faucet content script ──────────────────────────────────────────────────
// Runs on all *.pick.io pages. Only acts when the tab was opened by the plugin
// (guard prevents automating manual visits).
//
// Flow:
//   login page   → captcha → submit
//   faucet page  → captcha → click Claim → read balance → (auto-withdraw if needed)
//   withdraw page→ fill address + captcha → submit
//
// Shared constants and utilities (normalizeHost, toFiniteNumber, clampNumber,
// DEFAULT_USD5_WD_THRESHOLD_BY_HOST, WD_THRESHOLD_MIGRATION_BY_HOST) 
// are loaded from constants.js (injected first).

const POLL_MS            = 500;
const MAX_WAIT_MS        = 90000;
const POST_CLAIM_WAIT_MS = 5000;
const POST_WD_WAIT_MS    = 5000;
const RANDOM_DELAY_MIN_MS = 15000;  // 15 seconds
const RANDOM_DELAY_MAX_MS = 60000;  // 60 seconds

// Enhanced reliability settings for login and captcha
const LOGIN_FORM_WAIT_MS = 20000;   // Wait for login fields to appear
const INPUT_SETTLE_MS    = 500;     // Time for form to settle after filling
const CAPTCHA_SETTLE_MS  = 1000;    // Time for captcha widget to settle
const CAPTCHA_RETRY_MS   = 1500;    // Retry captcha click every 1.5 seconds
const MAX_CAPTCHA_RETRIES = 60;     // Keep trying through longer challenge loads
const NATIVE_CLICK_MIN_INTERVAL_MS = 900;
const PHASE_HEARTBEAT_INTERVAL_MS = 15000;

let lastNativeClickAt = 0;
let lastPhaseHeartbeatAt = 0;

function log(...a) { console.log("[FaucetPlugin]", ...a); }
function sleep(ms) {
  return new Promise(function resolveSleep(resolveSleepPromise) {
    setTimeout(resolveSleepPromise, ms);
  });
}

function sameHost(url1, url2) {
  try {
    const host1 = new URL(url1).hostname;
    const host2 = new URL(url2).hostname;
    return host1 === host2;
  } catch {
    return url1 === url2;
  }
}

/**
 * Executes a pre-defined action in the page's main execution context (the 'window' world)
 * via a secure background bridge. This avoids CSP-violating inline script injections.
 */
async function runInPageContextBridge(action, ...args) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: "execute-in-page", action, args }, (resp) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (resp && resp.error) {
        reject(new Error(resp.error));
        return;
      }
      resolve(resp);
    });
  });
}


// Generate random delay between 15-60 seconds to avoid detection
function randomDelay() {
  return RANDOM_DELAY_MIN_MS + Math.random() * (RANDOM_DELAY_MAX_MS - RANDOM_DELAY_MIN_MS);
}

function randomIntInclusive(min, max) {
  const safeMin = Math.ceil(Math.min(min, max));
  const safeMax = Math.floor(Math.max(min, max));
  return Math.floor(Math.random() * (safeMax - safeMin + 1)) + safeMin;
}

function getUsdFiveWdThresholdForHost(host) {
  const fallback = DEFAULT_USD5_WD_THRESHOLD_BY_HOST[normalizeHost(host)] || "5";
  const parsed = parseFloat(fallback);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 5;
}

function normalizeWdThresholdForHost(host, rawThreshold) {
  const fallback = getUsdFiveWdThresholdForHost(host);
  const parsed = parseFloat(rawThreshold);
  if (!Number.isFinite(parsed) || parsed <= 0) return fallback;

  const hostKey = normalizeHost(host);
  const migrationCandidates = WD_THRESHOLD_MIGRATION_BY_HOST[hostKey] || [];
  for (const candidateRaw of migrationCandidates) {
    const candidateParsed = parseFloat(candidateRaw);
    if (Number.isFinite(candidateParsed) && Math.abs(parsed - candidateParsed) < 1e-12) {
      return fallback;
    }
  }

  return parsed;
}


function sendDone(balance)   { chrome.runtime.sendMessage({ type: "faucet-done",   balance }); }
function sendError(reason)   { chrome.runtime.sendMessage({ type: "faucet-error",  reason }); }
function sendWdDone()        { chrome.runtime.sendMessage({ type: "withdraw-done" }); }
function sendWdError(reason) { chrome.runtime.sendMessage({ type: "withdraw-error", reason }); }

function sendPhaseHeartbeat(detail = "") {
  const now = Date.now();
  if (now - lastPhaseHeartbeatAt < PHASE_HEARTBEAT_INTERVAL_MS) return;
  lastPhaseHeartbeatAt = now;
  chrome.runtime.sendMessage({ type: "phase-heartbeat", phase: "faucet", detail, ts: now });
}

// ── Main Execution Flow ───────────────────────────────────────────────────────

async function main() {
  // Give background script and site assets/balance a moment to load
  await sleep(800);

  const pluginTab = await isPluginTab();
  if (!pluginTab) {
    log("Not a plugin-managed tab. Automation disabled.");
    return;
  }

  log("Plugin tab detected. Starting automation...");


  const wdInfo = await getWithdrawInfo();
  if (wdInfo.isWithdrawTab) {
    log("Detected withdrawal tab");
    await runWithdraw(wdInfo.address);
    return;
  }

  log("Checking page type...");
  if (hasLoginForm()) {
    log("Detected login page");
    await runLogin();
  } else if (isFaucetPage()) {
    log("Detected faucet page");
    await runFaucet();
  } else {
    const tabState = await getCurrentTabState();
    const targetFaucetUrl = tabState?.faucetUrl;
    if (tabState?.phase === "faucet" && !!targetFaucetUrl && !isWithdrawPage() && !hasLoginForm()) {
      try {
        const target = new URL(targetFaucetUrl);
        if (target.hostname === location.hostname && location.href !== targetFaucetUrl) {
          log("Redirecting back to faucet:", targetFaucetUrl);
          location.href = targetFaucetUrl;
          return;
        }
      } catch (_) {}
    }
    log("Waiting for navigation:", location.href);
  }
}

main();

function isPluginTab() {
  return new Promise(resolve => {
    function handleResponse(resp) {
      if (chrome.runtime.lastError) {
        log("Error checking plugin tab status:", chrome.runtime.lastError.message);
        resolve(false);
        return;
      }
      resolve(!!resp?.yes);
    }
    chrome.runtime.sendMessage({ type: "check-plugin-tab" }, handleResponse);
  });
}

function getWithdrawInfo() {
  return new Promise(resolve => {
    function handleWithdrawInfoResponse(resp) {
      if (chrome.runtime.lastError) { resolve({ isWithdrawTab: false, address: "" }); return; }
      resolve(resp || { isWithdrawTab: false, address: "" });
    }
    chrome.runtime.sendMessage({ type: "get-withdraw-info" }, handleWithdrawInfoResponse);
  });
}

function getCurrentTabState() {
  return new Promise(resolve => {
    function handleTabStateResponse(resp) {
      if (chrome.runtime.lastError) { resolve(null); return; }
      resolve(resp?.tabState || null);
    }
    chrome.runtime.sendMessage({ type: "get-tab-state" }, handleTabStateResponse);
  });
}

// ── Page-type detection ───────────────────────────────────────────────────────

function isFaucetPage()   { return location.pathname.includes("faucet.php"); }
function isWithdrawPage() { return /withdraw/i.test(location.pathname); }
function hasLoginForm()   { return !!document.querySelector('input[type="password"]'); }


// ── Credentials from storage ──────────────────────────────────────────────────



function triggerInputEvents(input) {
  if (!input) return;
  input.dispatchEvent(new Event("input",  { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  input.dispatchEvent(new Event("blur",   { bubbles: true }));
}

function fillInput(input, value) {
  if (!input) return;
  input.focus();
  input.value = value;
  triggerInputEvents(input);
}

async function waitForPasswordManagerAutofill(userInput, pwdInput, timeoutMs = 15000) {
  const started = Date.now();
  let nudged = false;

  while (Date.now() - started < timeoutMs) {
    const username = userInput?.value?.trim() || "";
    const password = pwdInput?.value?.trim() || "";

    if (password) return { username, password };

    // Nudge once: focusing fields often triggers browser autofill on supported forms.
    if (!nudged) {
      if (userInput) userInput.focus();
      await sleep(200);
      if (pwdInput) pwdInput.focus();
      nudged = true;
    }

    await sleep(300);
  }

  return null;
}

// ── Scrolling ─────────────────────────────────────────────────────────────────

function scrollToBottom() {
  window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
  const main = document.querySelector("main, .container, #content, #wrap");
  if (main) main.scrollTo({ top: main.scrollHeight, behavior: "smooth" });
}

// ── Captcha handling ──────────────────────────────────────────────────────────

function getCaptchaToken() {
  // Turnstile / hCaptcha / reCaptcha
  const el = document.querySelector(
    'input[name="cf-turnstile-response"], ' +
    'input[name="h-captcha-response"], ' +
    'input[name="g-recaptcha-response"]'
  );
  if (el && el.value) return el.value;

  // IconCaptcha — token input filled when user completes the icon challenge
  const ic = document.querySelector(
    'input[name="iconcaptcha-token"], ' +
    'input[name="ic-token"], ' +
    '.iconcaptcha-token'
  );
  if (ic && ic.value) return ic.value;

  // IconCaptcha completion state — widget gets a "passed" / "done" class
  if (document.querySelector('.iconcaptcha-holder.iconcaptcha-passed, .iconcaptcha-holder[data-completed="true"]'))
    return "iconcaptcha-passed";

  return null;
}

/**
 * Enhanced Turnstile captcha checkbox clicking.
 * Handles multiple widget types and tries multiple strategies.
 */
function isVisibleForClick(el) {
  if (!el) return false;
  const rect = el.getBoundingClientRect();
  const style = window.getComputedStyle(el);
  return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
}

function dispatchMouseEvent(el, type, x, y) {
  const EventCtor = type.startsWith("pointer") && typeof PointerEvent !== "undefined" ? PointerEvent : MouseEvent;
  const payload = {
    bubbles: true,
    cancelable: true,
    composed: true,
    clientX: x,
    clientY: y,
    button: 0
  };
  if (EventCtor === PointerEvent) {
    payload.pointerId = 1;
    payload.pointerType = "mouse";
    payload.isPrimary = true;
  }
  el.dispatchEvent(new EventCtor(type, payload));
}

function requestNativeClick(x, y, label) {
  if (!Number.isFinite(x) || !Number.isFinite(y)) return;
  const now = Date.now();
  if (now - lastNativeClickAt < NATIVE_CLICK_MIN_INTERVAL_MS) return;
  lastNativeClickAt = now;

  function handleNativeClickResponse(resp) {
    if (chrome.runtime.lastError) {
      log(`Native click message failed for ${label}: ${chrome.runtime.lastError.message}`);
      return;
    }
    if (resp?.ok) {
      log(`Native click dispatched for ${label}`);
    } else if (resp?.error) {
      log(`Native click failed for ${label}: ${resp.error}`);
    }
  }

  chrome.runtime.sendMessage(
    { type: "native-click", x: Math.round(x), y: Math.round(y), label },
    handleNativeClickResponse
  );
}

function clickElementRobust(el, label) {
  if (!isVisibleForClick(el)) return false;

  try { el.scrollIntoView({ block: "center", inline: "center" }); } catch (_) {}
  const rect = el.getBoundingClientRect();
  const x = rect.left + rect.width / 2;
  const y = rect.top + rect.height / 2;
  let target = document.elementFromPoint(x, y) || el;

  try { if (target.focus) target.focus({ preventScroll: true }); } catch (_) {
    try { if (target.focus) target.focus(); } catch (_) {}
  }

  for (const evt of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
    try { dispatchMouseEvent(target, evt, x, y); } catch (_) {}
  }

  try { target.click(); } catch (_) {}
  if (target !== el) {
    try { el.click(); } catch (_) {}
  }

  requestNativeClick(x, y, label);

  log(`Clicked ${label}`);
  return true;
}

function tryClickCaptchaWidget() {
  // Strategy 1: Click explicit Turnstile iframes (most common rendering path)
  const turnstileFrames = [
    ...document.querySelectorAll('iframe[src*="challenges.cloudflare.com"][src*="turnstile"]'),
    ...document.querySelectorAll('iframe[src*="challenges.cloudflare.com"]'),
    ...document.querySelectorAll('iframe[src*="turnstile"]'),
    ...document.querySelectorAll('iframe[src*="captcha"]'),
    ...document.querySelectorAll('iframe[title*="turnstile" i]')
  ];
  for (const frame of turnstileFrames) {
    if (clickElementRobust(frame, "Turnstile iframe")) return true;
  }

  // Strategy 2: Click Turnstile checkbox directly when present in DOM
  const turnstileCheckboxes = [
    ...document.querySelectorAll('.cf-turnstile input[type="checkbox"]'),
    ...document.querySelectorAll('input[type="checkbox"][name*="turnstile" i]')
  ];
  for (const checkbox of turnstileCheckboxes) {
    if (checkbox.checked) continue;
    if (clickElementRobust(checkbox, "Turnstile checkbox")) return true;
  }

  // Strategy 3: Click Turnstile container
  let widget = document.querySelector('.cf-turnstile, [id*="turnstile" i], [class*="turnstile" i], [data-turnstile-callback]');
  if (widget && clickElementRobust(widget, "Turnstile container")) {
    return true;
  }

  // Strategy 4: Try hCaptcha
  widget = document.querySelector('.h-captcha');
  if (widget && clickElementRobust(widget, "hCaptcha widget")) {
    return true;
  }

  // Strategy 5: Look for any element with data-sitekey (generic captcha container)
  widget = document.querySelector('[data-sitekey]');
  if (widget && clickElementRobust(widget, "generic captcha container")) {
    return true;
  }

  // Strategy 6: Look for invisible Turnstile (no visible checkbox)
  // Try to trigger it by clicking on the page
  let invisibleTurnstile = document.querySelector('[data-turnstile-callback], [id*="turnstile"]');
  if (invisibleTurnstile && clickElementRobust(invisibleTurnstile, "invisible Turnstile trigger")) {
    return true;
  }

  // Strategy 7: IconCaptcha
  widget = document.querySelector('.iconcaptcha-holder');
  if (widget && clickElementRobust(widget, "IconCaptcha widget")) {
    return true;
  }

  log("No captcha widget found to click");
  return false;
}

function hasCaptchaWidget() {
  return !!(
    document.querySelector('.cf-turnstile, .h-captcha, [data-sitekey], .iconcaptcha-holder, [data-turnstile-callback], [id*="turnstile" i], [class*="turnstile" i]') ||
    document.querySelector('iframe[src*="challenges.cloudflare.com"], iframe[src*="turnstile"], iframe[src*="captcha"], iframe[title*="turnstile" i], iframe[src*="hcaptcha.com"]') ||
    document.querySelector('input[name="cf-turnstile-response"], input[name="h-captcha-response"], input[name="g-recaptcha-response"], input[name="iconcaptcha-token"], input[name="ic-token"]')
  );
}

/**
 * Enhanced captcha token waiting with multiple retry strategies.
 * More reliable Turnstile/hCaptcha handling.
 */
function waitForCaptchaToken(timeoutMs = MAX_WAIT_MS) {
  return new Promise(function waitForCaptchaTokenPromise(resolveCaptchaToken) {
    const start = Date.now();
    let clickAttempts = 0;
    let lastClickTime = 0;
    let lastFocusTime = 0;
    const maxClickAttempts = Math.max(MAX_CAPTCHA_RETRIES, Math.ceil(timeoutMs / CAPTCHA_RETRY_MS));
    let timer = null;

    log(`Waiting for captcha token (timeout: ${timeoutMs}ms)...`);

    function pollCaptchaToken() {
      const token = getCaptchaToken();
      if (token) {
        log(`✓ Captcha token obtained after ${Date.now() - start}ms`);
        clearInterval(timer);
        resolveCaptchaToken(token);
        return;
      }

      const elapsed = Date.now() - start;
      const now = Date.now();

      if (now - lastFocusTime >= 10000) {
        chrome.runtime.sendMessage({ type: "focus-tab" });
        lastFocusTime = now;
      }

      // Periodically try clicking the captcha widget
      if (now - lastClickTime >= CAPTCHA_RETRY_MS && clickAttempts < maxClickAttempts) {
        const clicked = tryClickCaptchaWidget();
        if (clicked) {
          lastClickTime = now;
          clickAttempts++;
          log(`Captcha click attempt ${clickAttempts}/${maxClickAttempts}`);
        }
      }

      // Timeout check
      if (elapsed > timeoutMs) {
        log(`✗ Captcha timeout after ${elapsed}ms (${clickAttempts} click attempts)`);
        clearInterval(timer);
        resolveCaptchaToken(null);
      }
    }

    timer = setInterval(pollCaptchaToken, POLL_MS);
  });
}

// ── Balance detection ─────────────────────────────────────────────────────────

function parseNumericValue(rawText) {
  if (typeof rawText !== "string") return null;
  const cleaned = rawText.replace(/,/g, "");
  const match = cleaned.match(/-?\d+(?:\.\d+)?/);
  if (!match) return null;
  const value = parseFloat(match[0]);
  return Number.isFinite(value) ? value : null;
}

function readBalance() {
  const preferredSelectors = [
    ".user_balance",
    ".balance-value",
    "#balance",
    ".bal-amt"
  ];

  for (const sel of preferredSelectors) {
    const el = document.querySelector(sel);
    if (!el) continue;
    
    // Ignore hidden elements (like placeholders with 0.00000000)
    if (el.offsetParent === null && !el.classList.contains('user_balance')) {
      continue;
    }

    const value = parseNumericValue(el.textContent?.trim() || "");
    if (value != null) {
      log(`Fetched balance from preferred selector "${sel}": ${value}`);
      return value;
    }
  }

  const selectors = [
    '[class*="balance"]', '[id*="balance"]',
    '[class*="wallet"]',  '[id*="wallet"]',
    '[class*="amount"]',  '[id*="amount"]',
    '.bal', '#bal',
    '.user-info b', '.navbar-text b'
  ];
  for (const sel of selectors) {
    for (const el of document.querySelectorAll(sel)) {
      if (!el.offsetParent) continue;
      const value = parseNumericValue(el.textContent?.trim() || "");
      if (value != null) return value;
    }
  }
  return null;
}

function scrapeMinimumWithdrawal() {
  const textContent = document.body.innerText;
  const patterns = [
    /minimum\s+(?:withdrawal|withdraw|amount)[:\s]+([\d.]+)/i,
    /min[:\s]+([\d.]+)/i,
    /withdraw\s+min[:\s]+([\d.]+)/i,
    /least[:\s]+([\d.]+)\s+\w+\s+to\s+withdraw/i
  ];

  for (const pattern of patterns) {
    const match = textContent.match(pattern);
    if (match && match[1]) {
      const val = parseFloat(match[1]);
      if (Number.isFinite(val) && val > 0) {
        log(`✓ Scraped minimum withdrawal: ${val}`);
        return val;
      }
    }
  }

  // Look for it in specific elements
  const selectors = ['.min_withdraw', '#min_withdraw', '.withdrawal_min', '.alert-info', '.text-muted'];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (!el) continue;
    const val = parseNumericValue(el.textContent);
    if (val != null && val > 0 && /min|least/i.test(el.textContent)) {
      log(`✓ Scraped minimum withdrawal from ${sel}: ${val}`);
      return val;
    }
  }

  return null;
}

// ── Auto-capture login credentials ─────────────────────────────────────────────
// When user logs in manually without stored credentials, capture and save them



async function getFaucetUrl() {
  const tabState = await getCurrentTabState();
  if (tabState?.faucetUrl) return tabState.faucetUrl;
  return location.origin + '/faucet.php';
}

// ── Login flow ────────────────────────────────────────────────────────────────

async function runLogin() {
  log("Login page:", location.href);

  await sleep(1500);
  scrollToBottom();
  await sleep(800);

  // Wait for login inputs to appear (some sites don't wrap them in a <form>)
  let form = null;
  let loginScope = null;
  let pwdInput = null;
  let attemptCount = 0;
  const maxAttempts = Math.ceil(LOGIN_FORM_WAIT_MS / 500);

  for (let i = 0; i < maxAttempts; i++) {
    form = [...document.querySelectorAll("form")].find(f => f.querySelector('input[type="password"]'));
    pwdInput = form?.querySelector('input[type="password"]') || document.querySelector('input[type="password"]');

    if (pwdInput) {
      loginScope = form || pwdInput.closest("form") || document;
      log(`✓ Login inputs found on attempt ${i + 1}/${maxAttempts} (${loginScope === document ? "document scope" : "form scope"})`);
      break;
    }
    attemptCount = i + 1;
    await sleep(500);
  }

  if (!pwdInput) {
    log(`✗ Password input not found after ${attemptCount} attempts (${attemptCount * 500}ms)`);
    sendError("no-password-input");
    return;
  }

  // Find username input with enhanced selector strategy
  const usernameSelector =
    'input[type="email"], ' +
    'input[name*="user" i], ' +
    'input[name*="email" i], ' +
    'input[name*="login" i], ' +
    'input[name*="account" i], ' +
    'input[name*="username" i], ' +
    'input[autocomplete="username" i], ' +
    'input[type="text"][name]:not([readonly]), ' +
    'input[type="text"]';
  const userInput =
    loginScope.querySelector(usernameSelector) ||
    document.querySelector(usernameSelector);

  log("Waiting for Chrome Password Manager autofill...");
  // Nudge browser
  if (userInput) userInput.focus();
  await sleep(100);
  if (pwdInput) pwdInput.focus();

  const autofilled = await waitForPasswordManagerAutofill(userInput, pwdInput);
  if (!autofilled) {
    if (hasCaptchaWidget()) {
      log("Captcha present on login page, trying automatic checkbox click while waiting for manual login");
      chrome.runtime.sendMessage({ type: "focus-tab" });
      await sleep(400);
      tryClickCaptchaWidget();
    }
    log("No autofilled credentials detected — waiting for manual login");
    return;
  }

  log(`✓ Using Chrome Password Manager autofill for ${autofilled.username || "saved account"}`);
  triggerInputEvents(userInput);
  triggerInputEvents(pwdInput);
  await sleep(INPUT_SETTLE_MS);

  log("✓ Credentials filled, waiting for page to settle...");
  await sleep(CAPTCHA_SETTLE_MS);

  // Handle captcha if present
  if (hasCaptchaWidget()) {
    log("Captcha detected on login page");
    chrome.runtime.sendMessage({ type: "focus-tab" });
    await sleep(500); // Give tab time to focus

    // Try clicking captcha immediately and then let waitForCaptchaToken handle retries
    log("Attempting initial captcha click...");
    tryClickCaptchaWidget();
    await sleep(CAPTCHA_SETTLE_MS);

    const token = await waitForCaptchaToken(90000); // 90 second timeout for login
    if (!token) {
      log("✗ Login captcha timeout");
      sendError("login-captcha-timeout");
      return;
    }
    log("✓ Login captcha resolved");
  } else {
    log("No captcha on login page");
  }

  // Find and click submit button with enhanced selectors
  const submitBtn =
    loginScope.querySelector('button[type="submit"]:not([disabled])') ||
    loginScope.querySelector('button[type="submit"]') ||
    loginScope.querySelector('input[type="submit"]:not([disabled])') ||
    loginScope.querySelector('input[type="submit"]') ||
    [...document.querySelectorAll('button, input[type="submit"], input[type="button"], a[role="button"]')]
      .find(el => !el.disabled && /login|log in|sign in|submit|continue/i.test((el.textContent || el.value || "").trim())) ||
    loginScope.querySelector('button:not([disabled])') ||
    document.querySelector('button:not([disabled])');

  if (!submitBtn) {
    log("✗ Submit button not found");
    sendError("no-submit-button");
    return;
  }

  log(`✓ Found submit button: "${submitBtn.textContent?.trim() || submitBtn.value || 'Submit'}"`);
  log("Submitting login form...");
  
  // Ensure button is visible and clickable
  if (submitBtn.offsetParent === null) {
    log("Warning: Submit button is hidden, scrolling into view");
    submitBtn.scrollIntoView({ behavior: "smooth", block: "center" });
    await sleep(500);
  }

  if (!clickElementRobust(submitBtn, "login submit button")) {
    try { submitBtn.click(); } catch (_) {}
  }
  log("✓ Login form submitted");
  // Browser navigates → content script re-fires on faucet.php
  
  // Add random delay to avoid detection
  const delay = randomDelay();
  log(`Waiting ${(delay/1000).toFixed(1)}s before next action...`);
  await sleep(delay);
}

// ── Faucet claim flow ─────────────────────────────────────────────────────────

async function runFaucet() {
  log("Faucet page:", location.href);

  await sleep(2000);

  try {
    // ── Normal claim first ──
    scrollToBottom();
    await sleep(1000);
    scrollToBottom();

    // Check if captcha is even present
    const hasCaptcha = hasCaptchaWidget();
    log("Captcha widget present:", hasCaptcha);

    if (hasCaptcha) {
      log("Captcha detected on faucet page, requesting tab focus...");
      chrome.runtime.sendMessage({ type: "focus-tab" });
      await sleep(500); // Give tab time to focus

      // Try initial click and let waitForCaptchaToken handle retries
      log("Attempting initial captcha widget click...");
      const clicked = tryClickCaptchaWidget();
      if (clicked) {
        log("Initial captcha click succeeded, waiting for response...");
        await sleep(CAPTCHA_SETTLE_MS);
      } else {
        log("Initial captcha click failed, will retry in waitForCaptchaToken...");
      }

      const token = await waitForCaptchaToken(MAX_WAIT_MS);
      if (!token) {
        log("✗ Captcha timeout on faucet page");
        sendError("turnstile-timeout");
        return;
      }
      log("✓ Captcha resolved");
    } else {
      log("No captcha detected — proceeding directly to claim");
    }

    const claimKeywords = ["claim", "collect", "roll", "submit", "get"];
    const selectors = [
      'button[type="submit"]', 'input[type="submit"]',
      'button.btn-claim', 'button.claim', '#claim',
      'button[onclick*="claim" i]', 'button[onclick*="roll" i]',
      'button[class*="claim"]', 'button[class*="submit"]',
      'a[onclick*="claim" i]', 'a[onclick*="roll" i]',
      'input[value*="claim" i]', 'input[value*="roll" i]',
      'button', 'input[type="button"]'
    ];
    let btn = null;
    outer: for (const sel of selectors) {
      const elements = document.querySelectorAll(sel);
      log(`Searching with selector "${sel}" — found ${elements.length} element(s)`);
      for (const el of elements) {
        if (!el.offsetParent) continue; // skip hidden elements
        const text = (el.textContent || el.value || "").trim().toLowerCase();
        if (claimKeywords.some(k => text.includes(k))) {
          log(`✓ Matched selector "${sel}" with text "${text}"`);
          btn = el;
          break outer;
        }
      }
    }

    if (!btn) {
      log("WARNING: No claim button found with keyword matching");
      log("Trying fallback: any visible submit button");
      btn = document.querySelector('button[type="submit"], input[type="submit"]');
      if (btn) log(`Found fallback button: ${btn.textContent?.trim() || btn.value}`);
    }

    // Safety: don't submit a login form from the faucet flow
    if (!btn) {
      log("ERROR: No claim button found at all. Page structure might be different.");
      sendError("no-claim-button");
      return;
    }

    if (hasLoginForm()) {
      log("ERROR: Login form detected on faucet page. Aborting claim.");
      sendError("login-form-detected");
      return;
    }

    log("Clicking claim button:", btn.textContent?.trim() || btn.value);
    btn.click();

    await sleep(POST_CLAIM_WAIT_MS);

    // ── Bonus faucet claims after normal claim ──
    await claimBonusFaucets();

    const balance = readBalance();
    log("Balance after claim:", balance);


    // Add random delay before reporting completion
    const delay = randomDelay();
    log(`Claim completed, waiting ${(delay/1000).toFixed(1)}s before next action`);
    await sleep(delay);

    sendDone(balance);
  } catch (err) {
    log("ERROR in runFaucet:", err.message);
    sendError("faucet-run-error");
  }
}

// ── Bonus faucet loop ─────────────────────────────────────────────────────────
// The faucet page has a "Bonus Faucet" tab at the top. After the main claim:
//  1. Find and click the bonus tab to switch to that section.
//  2. Inside that section, loop: wait for captcha → click claim → repeat until
//     no visible claim button remains (i.e. all bonus claims exhausted).

const NO_MORE_PATTERNS = /no more|no bonus|all claimed|come back|no free|exhausted|used up|no spins|0 spins/i;

function bonusExhausted() {
  // Check badge is 0
  const badge = document.getElementById('free_spins');
  if (badge && parseInt(badge.textContent) <= 0) {
    log("Bonus exhausted: free_spins badge = 0");
    return true;
  }
  
  // Check for a visible "no more" message anywhere on page
  const msgEls = document.querySelectorAll('.alert, .message, .msg, .info, .notice, [class*="alert"], [class*="message"], [class*="result"], p, span, div');
  for (const el of msgEls) {
    if (!el.offsetParent) continue;
    if (el.children.length > 3) continue; // skip containers
    if (NO_MORE_PATTERNS.test(el.textContent)) {
      log(`Bonus exhausted: found message "${el.textContent.trim().substring(0, 50)}"`);
      return true;
    }
  }
  
  return false;
}


const CLAIM_KEYWORDS      = ["claim", "collect", "roll", "submit", "get", "spin"];

function findBonusTab() {
  // Try multiple selectors to find bonus tab
  const selectors = [
    '[data-type="bonus"].faucet-tab',
    '[data-type="bonus"]',
    'div[data-type="bonus"]',
    'a[data-type="bonus"]',
    '.faucet-tab[data-type="bonus"]',
    '[data-tab="bonus"]',
    'button[data-tab="bonus"]',
    '#bonus-tab',
    '.bonus-tab',
    'li[data-type="bonus"]',
    '[class*="bonus"][class*="tab"]'
  ];
  
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el && el.offsetParent !== null) {
      log(`Found bonus tab with selector: ${sel}`);
      return el;
    }
  }
  
  // Fallback: search ALL elements for text containing "bonus"
  const allElements = document.querySelectorAll('*');
  for (const el of allElements) {
    if (el.offsetParent === null) continue; // hidden
    if (el.children.length > 5) continue; // skip containers
    const text = el.textContent?.trim().toLowerCase() || '';
    if ((text === 'bonus' || text === 'bonus roll' || text === 'bonus faucet') && el.tagName !== 'BODY' && el.tagName !== 'HTML') {
      // Found a bonus text - check if it's clickable (tab-like)
      if (el.onclick || el.getAttribute('data-tab') || el.className.includes('tab') || el.className.includes('nav')) {
        log(`Found bonus tab by text search (exact): "${el.textContent.trim()}"`);
        return el;
      }
    }
    if (/^bonus|bonus roll|bonus faucet|bonus spins|free spins/.test(text) && el.className.includes('tab')) {
      log(`Found bonus tab by text pattern: "${el.textContent.trim()}"`);
      return el;
    }
  }
  
  return null;
}

// Find a claim button in a specific container (for bonus section targeting)
function findClaimButtonInContext(context = document) {
  // Find a visible claim/submit button that is NOT disabled
  // Search within the context (default: whole page)
  for (const el of context.querySelectorAll('button, input[type="submit"], input[type="button"], a[onclick]')) {
    if (!el.offsetParent) continue; // element is hidden
    if (el.disabled) continue;
    
    // Skip dice-related buttons
    const onclick = el.getAttribute('onclick') || '';
    const text = (el.textContent || el.value || onclick).toLowerCase();
    if (text.includes('dice') || onclick.includes('dice')) {
      log(`Skipping dice button: "${text.substring(0, 30)}"`);
      continue;
    }
    
    const trimText = (el.textContent || el.value || "").trim().toLowerCase();
    if (CLAIM_KEYWORDS.some(k => trimText.includes(k))) {
      log(`Found claim button in context: tag=${el.tagName}, text="${trimText.substring(0, 30)}"`);
      return el;
    }
  }
  
  // Fallback: search for elements by attribute (wider search)
  const btnByAttr = context.querySelector('[onclick*="claim" i], [onclick*="roll" i], [onclick*="submit" i], [class*="claim" i], [class*="roll" i]');
  if (btnByAttr && btnByAttr.offsetParent) {
    // Check if it's a dice button
    const onclick = btnByAttr.getAttribute('onclick') || '';
    if (!onclick.includes('dice')) {
      log(`Found claim button in context by attribute/class`);
      return btnByAttr;
    }
  }

  return null;
}

// Backwards compatibility - search whole page
function findClaimButton() {
  return findClaimButtonInContext(document);
}

async function claimBonusFaucets() {
  try {
    // Step 1 — find and click the bonus tab
    const bonusTab = findBonusTab();
    if (!bonusTab) {
      log("No bonus faucet tab found — skipping bonus round");
      return;
    }

    // Check the free_spins badge — skip if 0
    const spinsEl = bonusTab.querySelector('#free_spins, .badge');
    const spins = spinsEl ? parseInt(spinsEl.textContent) : NaN;
    if (!isNaN(spins) && spins <= 0) {
      log("Bonus faucet: 0 spins remaining — skipping");
      return;
    }

    log(`Clicking bonus tab: "${bonusTab.textContent.trim()}"`);
    bonusTab.click();
    await sleep(800);
    bonusTab.click(); // double-click to ensure
    await sleep(3000); // wait longer for tab content to render and load

    // Step 1b — find the bonus content container
    // Try to find the section that became visible after clicking the tab
    let bonusContent = document.querySelector('[data-type="bonus"][class*="content"], [data-tab="bonus"][class*="content"], .bonus-content, [aria-labelledby*="bonus"]');
    if (!bonusContent) {
      // Fallback: look for any visible container that appeared after the click
      const containers = document.querySelectorAll('[class*="tab-pane"], [class*="tab-content"], .content, [role="tabpanel"]');
      for (const c of containers) {
        if (c.offsetParent !== null) { // visible
          bonusContent = c;
          break;
        }
      }
    }
    if (!bonusContent) {
      bonusContent = document.body; // fallback to whole page
    }
    log(`Bonus content container identified`);

    // Step 2 — claim loop inside the bonus section
    let consecutiveNoButton = 0;
    for (let round = 1; round <= 30; round++) {
      // Wait briefly for the UI to settle between rounds
      await sleep(round === 1 ? 1000 : 2500);

      // Check badge / "no more" message before attempting
      if (bonusExhausted()) {
        log(`Bonus round ${round}: exhausted (badge check) — done`);
        break;
      }

      // Scroll so captcha / claim button is visible
      scrollToBottom();
      await sleep(600);

      // Handle captcha if present (30s timeout for bonus — don't block forever)
      if (hasCaptchaWidget()) {
        log(`Bonus round ${round}: waiting for captcha…`);
        chrome.runtime.sendMessage({ type: "focus-tab" });
        await sleep(400);
        setTimeout(tryClickCaptchaWidget, 1000);
        const token = await Promise.race([
          waitForCaptchaToken(),
          sleep(30000).then(() => null)
        ]);
        if (!token) { 
          log("Bonus captcha timed out — stopping bonus loop"); 
          break; 
        }
        log("Bonus captcha resolved");
        await sleep(1500);
      }

      // Search for claim button WITHIN the bonus content container
      const claimBtn = findClaimButtonInContext(bonusContent);
      if (!claimBtn) {
        consecutiveNoButton++;
        log(`Bonus round ${round}: no claim button found in bonus content (${consecutiveNoButton}x)`);
        if (consecutiveNoButton >= 2) {
          log("No button found twice in a row — stopping bonus loop");
          break;
        }
        continue;
      }

      consecutiveNoButton = 0;
      log(`Bonus round ${round}: clicking claim/roll button "${claimBtn.textContent?.trim() || claimBtn.value}"`);
      claimBtn.click();
      await sleep(POST_CLAIM_WAIT_MS + 1000); // longer wait after bonus claim

      // Check after claim whether all bonus spins are gone
      if (bonusExhausted()) {
        log(`Bonus round ${round}: exhausted after claim — done`);
        break;
      }
    }
    log("Bonus faucets claim loop completed");
  } catch (err) {
    log("ERROR in claimBonusFaucets:", err.message);
  }
}

// ── Withdrawal flow ───────────────────────────────────────────────────────────

async function runWithdraw(address) {
  log("Withdrawal page:", location.href, "address:", address);

  if (!address) { sendWdError("no-address-configured"); return; }

  // Wait for Rocket Loader to finish executing page scripts (jQuery etc.)
  await sleep(2000);
  await new Promise(function waitForJQuery(resolveWhenReady) {
    let done = false;
    let intervalId = null;
    let timeoutId = null;

    function finishWaitForJQuery() {
      if (done) return;
      done = true;
      if (intervalId) clearInterval(intervalId);
      if (timeoutId) clearTimeout(timeoutId);
      resolveWhenReady();
    }

    async function pollForJQuery() {
      const hasJQuery = await runInPageContextBridge("CHECK_JQUERY").catch(() => false);
      if (hasJQuery) finishWaitForJQuery();
    }

    intervalId = setInterval(pollForJQuery, 200);
    timeoutId = setTimeout(finishWaitForJQuery, 8000); // max 8s
  });
  await sleep(500);
  const hasJQuery = await runInPageContextBridge("CHECK_JQUERY").catch(() => false);
  log("jQuery available:", hasJQuery);

  // ── Scrape minimum withdrawal threshold ──
  const minWd = scrapeMinimumWithdrawal();
  if (minWd) {
    chrome.runtime.sendMessage({ type: "scraped-min-wd", url: location.href, value: minWd });
  }

  // ── Fill address ──
  const addrEl = document.getElementById('withdrawal_address') ||
    document.querySelector('[name*="address" i]') ||
    document.querySelector('[id*="address" i]');

  if (!addrEl) { sendWdError("no-address-input"); return; }
  log("Address element tag:", addrEl.tagName, "id:", addrEl.id);

  addrEl.focus();
  // Use jQuery val() if available (works for both input and textarea)
  if (hasJQuery) {
    runInPageContextBridge("FILL_WD_ADDR_JQUERY", address);
  } else {
    // Native setter — handle both input and textarea
    const proto = addrEl instanceof HTMLTextAreaElement
      ? window.HTMLTextAreaElement.prototype
      : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(addrEl, address);
    else addrEl.value = address;
    addrEl.dispatchEvent(new Event("input",  { bubbles: true }));
    addrEl.dispatchEvent(new Event("change", { bubbles: true }));
  }
  await sleep(1000); // Wait for form to settle after address fill
  log("Address filled:", addrEl.value);

  // ── Set max amount ──
  const maxBtn = document.getElementById('max_amount');
  if (maxBtn) {
    if (hasJQuery) {
      runInPageContextBridge("TRIGGER_MAX_AMOUNT_CLICK");
    } else {
      maxBtn.click();
    }
    await sleep(300);
    log("Clicked max_amount");
  }

  // ── Captcha — always wait on withdrawal page ──
  log("Waiting for withdrawal captcha…");
  chrome.runtime.sendMessage({ type: "focus-tab" });
  await sleep(400);
  setTimeout(tryClickCaptchaWidget, 1000);
  setTimeout(tryClickCaptchaWidget, 5000);
  const token = await waitForCaptchaToken();
  if (!token) { sendWdError("withdraw-captcha-timeout"); return; }
  log("Withdrawal captcha resolved");
  await sleep(800);

  // ── Submit ──
  const submitBtn =
    [...document.querySelectorAll("button")].find(b =>
      /withdraw|send|submit/i.test(b.textContent)
    ) ||
    document.querySelector('button[type="submit"]') ||
    document.querySelector('input[type="submit"]');

  if (!submitBtn) { sendWdError("no-submit-button"); return; }

  log("Submitting withdrawal:", submitBtn.textContent?.trim());
  submitBtn.click();

  await sleep(8000);
  log("Withdrawal done");
  
  // Add random delay before completing withdrawal
  const delay = randomDelay();
  log(`Withdrawal submitted, waiting ${(delay/1000).toFixed(1)}s before completion`);
  await sleep(delay);
  
  sendWdDone();
}

// ── Entry point ───────────────────────────────────────────────────────────────

console.log("[FaucetPlugin] Content script executing for:", window.location.hostname);

function handleMainError(err) {
  console.error("[FaucetPlugin] Unhandled error:", err);
  log("Unhandled error:", err);
  sendError(String(err));
}

main().catch(handleMainError);
