// ── Shared constants and utilities ──────────────────────────────────────────
// Single source of truth for values used across background.js, content.js,
// and popup.js. Loaded via importScripts() in the service worker, as the
// first content_script, and as the first <script> in popup.html.

// ── Per-host withdrawal thresholds (≈ $5 USD equivalent) ─────────────────────
const DEFAULT_USD5_WD_THRESHOLD_BY_HOST = Object.freeze({
  "litepick.io": "0.05",
  "dogepick.io": "30",
  "solpick.io":  "0.0325",
  "bnbpick.io":  "0.009",
  "tronpick.io": "40",
  "polpick.io":  "10",
  "tonpick.game": "1.0"
});

// ── CoinGecko Price IDs ───────────────────────────────────────────────────────
const CRYPTO_PRICE_IDS = Object.freeze({
  "litepick.io": "litecoin",
  "dogepick.io": "dogecoin",
  "solpick.io":  "solana",
  "bnbpick.io":  "binancecoin",
  "tronpick.io": "tron",
  "polpick.io":  "matic-network", // POL/MATIC
  "tonpick.game": "the-open-network"
});

// ── Old threshold values that should be silently upgraded to the new default ──
const WD_THRESHOLD_MIGRATION_BY_HOST = Object.freeze({
  "litepick.io": ["0.005", "0.01"],
  "dogepick.io": ["10.0", "6"],
  "solpick.io":  ["0.0025", "0.0065"],
  "bnbpick.io":  ["0.005", "0.018"],
  "tronpick.io": ["7.5", "8"],
  "polpick.io":  ["1.5", "2"],
  "tonpick.game": ["0.5", "0.25"]
});

// ── Random timing defaults ───────────────────────────────────────────────────
const DEFAULT_RANDOM_MIN = 1;
const DEFAULT_RANDOM_MAX = 10;

// ── Pure utility functions ────────────────────────────────────────────────────

function normalizeHost(host) {
  return String(host || "").replace(/^www\./i, "").toLowerCase();
}

function toFiniteNumber(value, fallback) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function clampNumber(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

// Get price ID for host
function getPriceIdForHost(host) {
  return CRYPTO_PRICE_IDS[normalizeHost(host)] || null;
}

// Returns the per-host default WD threshold string for a faucet URL.
function getDefaultWdThresholdForUrl(url) {
  try {
    const host = normalizeHost(new URL(url).hostname);
    return DEFAULT_USD5_WD_THRESHOLD_BY_HOST[host] || "5";
  } catch {
    return "5";
  }
}

// Normalises a stored WD threshold string, migrating stale legacy values.
function normalizeWdThresholdForUrl(url, rawThreshold) {
  const fallback = getDefaultWdThresholdForUrl(url);
  const parsed = parseFloat(rawThreshold);
  if (!Number.isFinite(parsed) || parsed <= 0) return fallback;

  let host = "";
  try { host = normalizeHost(new URL(url).hostname); } catch {}

  for (const candidateRaw of WD_THRESHOLD_MIGRATION_BY_HOST[host] || []) {
    const candidateParsed = parseFloat(candidateRaw);
    if (Number.isFinite(candidateParsed) && Math.abs(parsed - candidateParsed) < 1e-12) {
      return fallback;
    }
  }
  return String(rawThreshold).trim();
}

// ── Default faucet list (single source of truth) ──────────────────────────────
// background.js and popup.js both use this to initialise / reset settings.
function makeFaucetDefaults() {
  return [
    { url: "https://litepick.io/faucet.php",  label: "litepick",  active: false, intervalMinutes: 61, minRandomMinutes: DEFAULT_RANDOM_MIN, maxRandomMinutes: DEFAULT_RANDOM_MAX, username: "", password: "", wdEnabled: true, wdThreshold: getDefaultWdThresholdForUrl("https://litepick.io/faucet.php"),  wdAddress: "", reflink: "https://litepick.io/?ref=frankgoosen" },
    { url: "https://dogepick.io/faucet.php",  label: "dogepick",  active: false, intervalMinutes: 61, minRandomMinutes: DEFAULT_RANDOM_MIN, maxRandomMinutes: DEFAULT_RANDOM_MAX, username: "", password: "", wdEnabled: true, wdThreshold: getDefaultWdThresholdForUrl("https://dogepick.io/faucet.php"), wdAddress: "", reflink: "https://dogepick.io/?ref=schnickfitzel" },
    { url: "https://solpick.io/faucet.php",   label: "solpick",   active: false, intervalMinutes: 61, minRandomMinutes: DEFAULT_RANDOM_MIN, maxRandomMinutes: DEFAULT_RANDOM_MAX, username: "", password: "", wdEnabled: true, wdThreshold: getDefaultWdThresholdForUrl("https://solpick.io/faucet.php"),  wdAddress: "", reflink: "https://solpick.io/?ref=tstehg" },
    { url: "https://bnbpick.io/faucet.php",   label: "bnbpick",   active: false, intervalMinutes: 61, minRandomMinutes: DEFAULT_RANDOM_MIN, maxRandomMinutes: DEFAULT_RANDOM_MAX, username: "", password: "", wdEnabled: true, wdThreshold: getDefaultWdThresholdForUrl("https://bnbpick.io/faucet.php"),  wdAddress: "", reflink: "https://bnbpick.io/?ref=schnickfitzel" },
    { url: "https://tronpick.io/faucet.php",  label: "tronpick",  active: false, intervalMinutes: 61, minRandomMinutes: DEFAULT_RANDOM_MIN, maxRandomMinutes: DEFAULT_RANDOM_MAX, username: "", password: "", wdEnabled: true, wdThreshold: getDefaultWdThresholdForUrl("https://tronpick.io/faucet.php"), wdAddress: "", reflink: "https://tronpick.io/?ref=schnickfitzel" },
    { url: "https://polpick.io/faucet.php",   label: "polpick",   active: false, intervalMinutes: 61, minRandomMinutes: DEFAULT_RANDOM_MIN, maxRandomMinutes: DEFAULT_RANDOM_MAX, username: "", password: "", wdEnabled: true, wdThreshold: getDefaultWdThresholdForUrl("https://polpick.io/faucet.php"),  wdAddress: "", reflink: "https://polpick.io/?ref=schnickfitzel" },
    { url: "https://tonpick.game/faucet.php", label: "tonpick",   active: false, intervalMinutes: 61, minRandomMinutes: DEFAULT_RANDOM_MIN, maxRandomMinutes: DEFAULT_RANDOM_MAX, username: "", password: "", wdEnabled: true, wdThreshold: getDefaultWdThresholdForUrl("https://tonpick.game/faucet.php"), wdAddress: "", reflink: "https://tonpick.game/?ref=schnickfitzel" }
  ];
}

