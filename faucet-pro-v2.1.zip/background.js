importScripts('constants.js');

const ALARM_NAME = "faucet-tick"; // fires every minute to check what's due
const SITE_PHASE_TIMEOUT_MS = 20 * 60 * 1000; // force-advance stuck site after 20 minutes

// Multi-site configuration: all enabled faucets are queued sequentially
const DEFAULT_SETTINGS = {
  enabled: true,
  faucets: makeFaucetDefaults()
};

async function getSettings() {
  const stored = await chrome.storage.local.get("settings");
  const s = stored.settings || {};
  const storedFaucets = s.faucets && s.faucets.length ? s.faucets : [];
  
  // Match by URL so adding new faucets doesn't lose stored per-faucet config
  const storedByUrl = {};
  for (const f of storedFaucets) { if (f.url) storedByUrl[f.url] = f; }
  
  const faucets = DEFAULT_SETTINGS.faucets.map(def => {
    const merged = { ...def, ...(storedByUrl[def.url] || {}) };
    return {
      ...merged,
      wdThreshold: normalizeWdThresholdForUrl(def.url, merged.wdThreshold)
    };
  });
  
  return { ...DEFAULT_SETTINGS, ...s, faucets };
}

function getWithdrawUrl(faucetUrl) {
  try { return new URL(faucetUrl).origin + "/withdraw.php"; } catch { return null; }
}

function sameHost(a, b) {
  try { return new URL(a).hostname === new URL(b).hostname; } catch { return false; }
}

function hostKey(url) {
  try { return new URL(url).hostname; } catch { return url || ""; }
}

let checkLoopRunning = false;
let pendingCheckRequested = false;
let pendingForceAll = false;

async function requestCheckAndRun(forceAll = false) {
  pendingCheckRequested = true;
  pendingForceAll = pendingForceAll || forceAll;
  if (checkLoopRunning) return;

  checkLoopRunning = true;
  try {
    while (pendingCheckRequested) {
      const runForceAll = pendingForceAll;
      pendingCheckRequested = false;
      pendingForceAll = false;
      await checkAndRun(runForceAll);
    }
  } catch (err) {
    console.error("[Faucet] check loop error:", err?.message || err);
  } finally {
    checkLoopRunning = false;
    if (pendingCheckRequested) {
      requestCheckAndRun(false);
    }
  }
}

// ── Alarm management ─────────────────────────────────────────────────────────

async function ensureTickAlarm() {
  const alarm = await chrome.alarms.get(ALARM_NAME);
  if (!alarm) {
    chrome.alarms.create(ALARM_NAME, { periodInMinutes: 1 });
    console.log("[Faucet] Tick alarm set (every 1 min)");
  }
}

async function cancelAlarm() {
  await chrome.alarms.clear(ALARM_NAME);
  console.log("[Faucet] Alarm cancelled");
}

// ── Check & open due faucets ─────────────────────────────────────────────────
// activeTabs = { [tabId]: { faucetUrl, phase, wdAddress? } }

async function checkAndRun(forceAll = false) {
  const s = await getSettings();
  if (!s.enabled) {
    console.log("[Faucet] Plugin disabled");
    await chrome.storage.local.set({ running: false });
    return;
  }

  const state = await chrome.storage.local.get(["claimHistory", "activeTabs", "claimQueue", "running"]);
  const claimHistory = state.claimHistory || {};
  const activeTabs = state.activeTabs || {};
  const claimQueue = Array.isArray(state.claimQueue) ? state.claimQueue : [];
  const schedulerRunning = state.running === true;
  const now = Date.now();

  console.log("[Faucet] Checking faucets...", s.faucets.length, "configured");
  console.log("[Faucet] Currently active tabs:", Object.keys(activeTabs).length);
  console.log("[Faucet] Queue length:", claimQueue.length);

  // Prune stale activeTabs entries whose tabs no longer exist
  const allTabIds = (await chrome.tabs.query({})).map(t => t.id);
  let stateDirty = false;
  const timedOutEntries = [];
  for (const id of Object.keys(activeTabs)) {
    const tabId = parseInt(id, 10);
    const entry = activeTabs[id];
    const phaseStartedAt = entry?.phaseStartedAt || entry?.startedAt || 0;
    const lastHeartbeatAt = entry?.lastHeartbeatAt || 0;
    const hasFreshHeartbeat = lastHeartbeatAt > 0 && (now - lastHeartbeatAt) <= SITE_PHASE_TIMEOUT_MS;

    if (!allTabIds.includes(tabId)) {
      delete activeTabs[id]; 
      stateDirty = true;
      console.log(`[Faucet] Removed stale tab ${id} from activeTabs`);
      continue;
    }

    if (phaseStartedAt && (now - phaseStartedAt) > SITE_PHASE_TIMEOUT_MS && !hasFreshHeartbeat) {
      delete activeTabs[id];
      stateDirty = true;
      timedOutEntries.push({ tabId, faucetUrl: entry?.faucetUrl, phase: entry?.phase || "unknown" });
      console.warn(`[Faucet] Timing out stuck tab ${id} phase=${entry?.phase || "unknown"}`);
      continue;
    }
  }

  // Keep only one active tab per faucet host (races can create duplicates)
  const duplicateHostEntries = [];
  const primaryByHost = {};
  const sortedActiveEntries = Object.entries(activeTabs).sort(([, a], [, b]) => {
    const aTs = a?.startedAt || a?.phaseStartedAt || 0;
    const bTs = b?.startedAt || b?.phaseStartedAt || 0;
    return aTs - bTs;
  });
  for (const [id, entry] of sortedActiveEntries) {
    const host = hostKey(entry?.faucetUrl);
    if (!host) continue;
    if (!primaryByHost[host]) {
      primaryByHost[host] = id;
      continue;
    }
    delete activeTabs[id];
    stateDirty = true;
    duplicateHostEntries.push({
      tabId: parseInt(id, 10),
      faucetUrl: entry?.faucetUrl,
      phase: entry?.phase || "unknown"
    });
    console.warn(`[Faucet] Removing duplicate active tab ${id} for host ${host}`);
  }

  for (const t of timedOutEntries) {
    try { await chrome.tabs.remove(t.tabId); } catch (_) {}
    if (t.faucetUrl) {
      await appendLog({ url: t.faucetUrl, status: "error", reason: `phase-timeout:${t.phase}`, ts: Date.now() });
    }
  }

  for (const t of duplicateHostEntries) {
    try { await chrome.tabs.remove(t.tabId); } catch (_) {}
    if (t.faucetUrl) {
      await appendLog({ url: t.faucetUrl, status: "error", reason: `duplicate-active-tab:${t.phase}`, ts: Date.now() });
    }
  }

  // Sanitize queue: remove hosts already active and remove duplicate hosts
  const activeHosts = new Set(
    Object.values(activeTabs)
      .map(tab => hostKey(tab?.faucetUrl))
      .filter(Boolean)
  );
  const seenQueueHosts = new Set();
  const sanitizedQueue = [];
  for (const url of claimQueue) {
    const host = hostKey(url);
    if (!host) {
      stateDirty = true;
      continue;
    }
    if (activeHosts.has(host)) {
      console.log(`[Faucet] Removing queued ${url} because host is already active`);
      stateDirty = true;
      continue;
    }
    if (seenQueueHosts.has(host)) {
      console.log(`[Faucet] Removing duplicate queued host ${host}`);
      stateDirty = true;
      continue;
    }
    seenQueueHosts.add(host);
    sanitizedQueue.push(url);
  }
  if (sanitizedQueue.length !== claimQueue.length) {
    claimQueue.length = 0;
    claimQueue.push(...sanitizedQueue);
  }

  // Build list of due faucets
  const dueFaucets = [];
  for (const f of s.faucets) {
    const isActive = f.active !== false;
    if (!isActive) {
      console.log(`[Faucet] ${f.url} — DISABLED (active=${f.active})`);
      continue;
    }
    const lastClaimed = claimHistory[f.url] || 0;
    const intervalMs  = (f.intervalMinutes || 61) * 60 * 1000;
    
    // Calculate random offset (forced 1-10 mins for production randomization)
    const minRand = 1 * 60 * 1000;
    const maxRand = 10 * 60 * 1000;
    const randomOffset = Math.floor(Math.random() * (maxRand - minRand + 1)) + minRand;
    
    const isDue       = forceAll || (now - lastClaimed) >= (intervalMs + randomOffset);
    const isRunning   = Object.values(activeTabs).some(t => sameHost(t.faucetUrl, f.url));
    const isQueued    = claimQueue.some(url => sameHost(url, f.url));
    const timeUntilDue = Math.max(0, (lastClaimed + intervalMs + randomOffset) - now);
    
    console.log(`[Faucet] ${f.url} — isDue=${isDue}, isRunning=${isRunning}, isQueued=${isQueued}, nextIn=${(timeUntilDue/1000/60).toFixed(1)}min (+rand)`);
    
    if (isDue && !isRunning && !isQueued) {
      dueFaucets.push(f);
      console.log(`[Faucet]   → Added to dueFaucets`);
    }
  }

  // Add due faucets to queue (avoid duplicates)
  for (const f of dueFaucets) {
    const isDuplicate = claimQueue.some(url => sameHost(url, f.url));
    if (!isDuplicate) {
      claimQueue.push(f.url);
      console.log(`[Faucet] Added to queue: ${f.url}`);
    } else {
      console.log(`[Faucet] SKIP: ${f.url} already in queue`);
    }
  }

  // If no tabs are running and queue has items, start the next one
  if (Object.keys(activeTabs).length === 0 && claimQueue.length > 0) {
    const nextUrl = claimQueue.shift();
    console.log(`[Faucet] No active tabs. Starting next from queue: ${nextUrl}`);
    
    try {
      const tab = await chrome.tabs.create({ url: nextUrl, active: false });
      console.log(`[Faucet] ✓ Opened tab ${tab.id} for ${nextUrl}`);
      activeTabs[tab.id] = { faucetUrl: nextUrl, phase: "faucet", startedAt: Date.now(), phaseStartedAt: Date.now() };
      await chrome.storage.local.set({ activeTabs, claimQueue, running: true, lastRunStart: Date.now() });
      console.log(`[Faucet] ✓ Stored tab ${tab.id} in activeTabs`);
    } catch (err) {
      console.error(`[Faucet] ✗ ERROR opening ${nextUrl}:`, err.message);
      if (err.message.includes('no permission') || err.message.includes('No host permission')) {
        console.error(`[Faucet] ✗ PERMISSION DENIED! Extension doesn't have access to ${nextUrl}`);
        console.error(`[Faucet] ✗ You must grant permission at chrome://extensions → Details → Permissions`);
      }
      claimQueue.push(nextUrl); // re-queue on error
      await chrome.storage.local.set({ activeTabs, claimQueue, running: true });
    }
    return;
  }

  if (claimQueue.length > 0) {
    console.log(`[Faucet] Queue has ${claimQueue.length} items waiting for current claim to finish`);
  }

  if (stateDirty || claimQueue.length > 0 || !schedulerRunning) {
    await chrome.storage.local.set({ activeTabs, claimQueue, running: true });
  }
}

// ── Close tab + update running state ─────────────────────────────────────────

async function closeTab(tabId) {
  const { activeTabs = {}, settings = {} } = await chrome.storage.local.get(["activeTabs", "settings"]);
  delete activeTabs[tabId];
  const running = settings.enabled !== false;
  await chrome.storage.local.set({ activeTabs, running });
  try { await chrome.tabs.remove(tabId); } catch (_) {}
  console.log("[Faucet] Tab", tabId, "closed. Remaining active:", Object.keys(activeTabs).length);
}

async function dispatchNativeClick(tabId, x, y) {
  if (!Number.isFinite(x) || !Number.isFinite(y)) {
    throw new Error("invalid-click-coordinates");
  }

  const target = { tabId };
  const protocolVersion = "1.3";
  let attached = false;

  try {
    await chrome.debugger.attach(target, protocolVersion);
    attached = true;
  } catch (err) {
    throw new Error(`debugger-attach-failed: ${err?.message || err}`);
  }

  try {
    const moveParams = {
      type: "mouseMoved",
      x: Math.round(x),
      y: Math.round(y),
      button: "none",
      pointerType: "mouse"
    };
    const downParams = {
      type: "mousePressed",
      x: Math.round(x),
      y: Math.round(y),
      button: "left",
      clickCount: 1,
      pointerType: "mouse"
    };
    const upParams = {
      type: "mouseReleased",
      x: Math.round(x),
      y: Math.round(y),
      button: "left",
      clickCount: 1,
      pointerType: "mouse"
    };

    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", moveParams);
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", downParams);
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", upParams);
  } finally {
    if (attached) {
      try { await chrome.debugger.detach(target); } catch (_) {}
    }
  }
}

// ── Message handling ─────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // ── Sync Handlers ──
  
  if (msg.type === "focus-tab") {
    if (sender.tab?.id) chrome.tabs.update(sender.tab.id, { active: true });
    return;
  }

  if (msg.type === "check-plugin-tab") {
    chrome.storage.local.get("activeTabs").then(d => {
      const activeTabs = d.activeTabs || {};
      sendResponse({ yes: sender.tab?.id in activeTabs });
    });
    return true;
  }

  if (msg.type === "get-withdraw-info") {
    chrome.storage.local.get("activeTabs").then(d => {
      const tab = (d.activeTabs || {})[sender.tab?.id];
      sendResponse({ isWithdrawTab: tab?.phase === "withdraw", address: tab?.wdAddress || "" });
    });
    return true;
  }

  if (msg.type === "get-tab-state") {
    chrome.storage.local.get("activeTabs").then(d => {
      const tab = (d.activeTabs || {})[sender.tab?.id];
      sendResponse({ tabState: tab || null });
    });
    return true;
  }

  // ── Async Handlers (via handleMessage bridge) ──
  handleMessage(msg, sender, sendResponse);
  return true; // Keep message channel open for async response
});

async function handleMessage(msg, sender, sendResponse) {
  try {
    // ── Popup messages (no tab) ──────────────────────────────────────────────
    if (msg.type === "manual-run") {
      const { claimHistory = {} } = await chrome.storage.local.get("claimHistory");
      const s = await getSettings();
      for (const f of s.faucets) { if (f.active !== false) claimHistory[f.url] = 0; }
      await chrome.storage.local.set({ claimHistory });
      requestCheckAndRun(true);
      sendResponse({ ok: true });
      return;
    }


    if (msg.type === "save-settings") {
      const old = await getSettings();
      await chrome.storage.local.set({ settings: { ...old, ...msg.settings } });
      const s = await getSettings();
      if (s.enabled) {
        await chrome.storage.local.set({ running: true });
        ensureTickAlarm();
        requestCheckAndRun();
      } else {
        cancelAlarm();
        await chrome.storage.local.set({ running: false });
      }
      sendResponse({ ok: true });
      return;
    }

    if (msg.type === "reset-all-sites") {
      const faucets = makeFaucetDefaults();
      faucets[0].active = true;
      const defaultSettings = { enabled: true, faucets };
      await chrome.storage.local.set({ settings: defaultSettings, claimHistory: {}, claimQueue: [], activeTabs: {}, running: true });
      ensureTickAlarm();
      requestCheckAndRun(true);
      sendResponse({ ok: true });
      return;
    }

    if (msg.type === "native-click") {
      const tabId = sender.tab?.id;
      if (!tabId) { sendResponse({ ok: false, error: "no-tab" }); return; }
      chrome.tabs.update(tabId, { active: true }).catch(() => {});
      dispatchNativeClick(tabId, msg.x, msg.y)
        .then(() => sendResponse({ ok: true }))
        .catch(err => sendResponse({ ok: false, error: err.message }));
      return;
    }

    // ── Content-script messages (require a known tab) ────────────────────────
    const tabId = sender.tab?.id;
    if (!tabId) return;

    const { activeTabs = {}, claimHistory = {} } = await chrome.storage.local.get(["activeTabs", "claimHistory"]);
    const tabData = activeTabs[tabId];
    if (!tabData) return;

    // ── Main World Execution Bridge ──
    if (msg.type === "execute-in-page") {
      const { action, args = [] } = msg;
      
      const runner = (action, args) => {
        try {
          if (action === "CHECK_JQUERY") return !!(window.$ || window.jQuery);
          if (action === "FILL_WD_ADDR_JQUERY") {
            const [address] = args;
            const addrEl = document.getElementById('withdrawal_address') || document.querySelector('[name*="address" i]') || document.querySelector('[id*="address" i]');
            if (addrEl && window.$ && $(addrEl).val) { $(addrEl).val(address).trigger('input').trigger('change'); return true; }
            return false;
          }
          if (action === "TRIGGER_MAX_AMOUNT_CLICK") {
            if (window.$) { $('#max_amount').trigger('click'); return true; }
            return false;
          }
        } catch (err) { return { error: err.message }; }
        return null;
      };

      chrome.scripting.executeScript({
        target: { tabId },
        world: "MAIN",
        func: runner,
        args: [action, args]
      }).then(results => {
        sendResponse(results?.[0]?.result);
      }).catch(err => {
        sendResponse({ error: err.message });
      });
      return;
    }

    if (msg.type === "phase-heartbeat") {
      activeTabs[tabId] = { ...tabData, phaseStartedAt: Date.now(), lastHeartbeatAt: Date.now() };
      await chrome.storage.local.set({ activeTabs });
      sendResponse({ ok: true });
      return;
    }

    if (msg.type === "scraped-min-wd") {
      const { minWdThresholds = {} } = await chrome.storage.local.get("minWdThresholds");
      const host = hostKey(msg.url);
      if (host && msg.value) {
        minWdThresholds[host] = msg.value;
        await chrome.storage.local.set({ minWdThresholds });
      }
      sendResponse({ ok: true });
      return;
    }

    const s = await getSettings();
    const cfg = s.faucets.find(f => sameHost(f.url, tabData.faucetUrl));

      if (msg.type === "faucet-done" || msg.type === "faucet-error") {
        await appendLog({ url: tabData.faucetUrl, status: msg.type === "faucet-done" ? "ok" : "error", reason: msg.reason, balance: msg.balance, ts: Date.now() });
        if (msg.type === "faucet-done" && msg.balance != null && cfg) {
          const threshold = parseFloat(cfg.wdThreshold);
          if (!isNaN(threshold) && threshold > 0 && cfg.wdEnabled && cfg.wdAddress && msg.balance >= threshold) {
            activeTabs[tabId] = { ...tabData, phase: "withdraw", wdAddress: cfg.wdAddress, phaseStartedAt: Date.now() };
            await chrome.storage.local.set({ activeTabs });
            chrome.tabs.update(tabId, { url: getWithdrawUrl(cfg.url) });
            sendResponse({ ok: true });
            return;
          }
        }
      if (cfg) {
        if (msg.type === "faucet-error" && (msg.reason === "turnstile-timeout" || msg.reason === "login-captcha-timeout" || msg.reason === "no-password-input")) {
          // Transient error: retry in 10 minutes instead of full interval
          claimHistory[cfg.url] = Date.now() - ((cfg.intervalMinutes || 61) - 10) * 60 * 1000;
          console.log(`[Faucet] Transient error for ${cfg.url}. Scheduled retry in 10 mins.`);
        } else {
          claimHistory[cfg.url] = Date.now();
        }
      }
      await chrome.storage.local.set({ claimHistory });
      await closeTab(tabId);
      await requestCheckAndRun();
      sendResponse({ ok: true });
      return;
    }

    if (msg.type === "withdraw-done" || msg.type === "withdraw-error") {
      await appendLog({ url: tabData.faucetUrl, status: msg.type === "withdraw-done" ? "wd-ok" : "wd-error", reason: msg.reason, ts: Date.now() });
      if (cfg) {
        if (msg.type === "withdraw-error") {
          // Retry withdrawal sooner if it failed
          claimHistory[cfg.url] = Date.now() - ((cfg.intervalMinutes || 61) - 15) * 60 * 1000;
          console.log(`[Faucet] Withdrawal error for ${cfg.url}. Scheduled retry in 15 mins.`);
        } else {
          claimHistory[cfg.url] = Date.now();
        }
      }
      await chrome.storage.local.set({ claimHistory });
      await closeTab(tabId);
      await requestCheckAndRun();
      sendResponse({ ok: true });
      return;
    }

    sendResponse({ ok: false, error: "unknown-message-type" });
  } catch (err) {
    console.error("[Faucet] handleMessage Error:", err);
    sendResponse({ ok: false, error: err.message });
  }
}

// ── Alarm handler ─────────────────────────────────────────────────────────────

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) requestCheckAndRun();
  if (alarm.name === "price-update") fetchPrices();
});

// ── Install / startup ─────────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get("settings");
  if (!stored.settings) await chrome.storage.local.set({ settings: DEFAULT_SETTINGS });
  const s = await getSettings();
  await chrome.storage.local.set({ activeTabs: {}, running: s.enabled !== false });
  if (s.enabled) { ensureTickAlarm(); requestCheckAndRun(true); }
});

chrome.runtime.onStartup.addListener(async () => {
  const s = await getSettings();
  await chrome.storage.local.set({ activeTabs: {}, running: s.enabled !== false });
  if (s.enabled) { ensureTickAlarm(); requestCheckAndRun(); }
});

// ── Activity log ─────────────────────────────────────────────────────────────

async function appendLog(entry) {
  const { activityLog = [] } = await chrome.storage.local.get("activityLog");
  activityLog.unshift(entry);
  await chrome.storage.local.set({ activityLog: activityLog.slice(0, 30) });
}

// ── Price fetcher ────────────────────────────────────────────────────────────

async function fetchPrices() {
  try {
    const ids = Object.values(CRYPTO_PRICE_IDS).join(",");
    const url = `https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd`;
    const resp = await fetch(url);
    if (!resp.ok) throw new Error(`HTTP error ${resp.status}`);
    const data = await resp.json();
    await chrome.storage.local.set({ cryptoPrices: { data, ts: Date.now() } });
  } catch (err) {
    console.warn("[Faucet] Price fetch failed:", err.message);
  }
}

chrome.alarms.create("price-update", { periodInMinutes: 15 });
fetchPrices();
